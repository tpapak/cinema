## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>", eval = FALSE)

## -----------------------------------------------------------------------------
# library(gemtc)
# library(cinemar)
# 
# data(smoking)
# ab <- smoking$data.ab   # columns: study, treatment, responders, sampleSize
# 
# # --- Bayesian NMA, exactly as MetaInsight fits it ------------------------
# net   <- mtc.network(ab)
# model <- mtc.model(net, likelihood = "binom", link = "logit",
#                    linearModel = "random")
# res   <- mtc.run(model, n.adapt = 2000, n.iter = 10000)
# ranks <- rank.probability(res, preferredDirection = 1)   # for SUCRA

## -----------------------------------------------------------------------------
# D <- data.frame(
#   study = ab$study, id = ab$study, t = ab$treatment,
#   r = ab$responders, n = ab$sampleSize,
#   rob = 1L, indirectness = 1L
# )
# 
# write_cinema_cnm(
#   data     = D,
#   type     = "long_binary",
#   sm       = "OR",
#   model    = "random",
#   bayesian = res,      # gemtc mtc.result  -> Bayesian block (primary)
#   ranks    = ranks,    # rank probabilities -> SUCRA
#   title    = "Smoking cessation (Bayesian)",
#   file     = "smoking_bayesian.cnm"
# )

## -----------------------------------------------------------------------------
# comps <- data.frame(
#   comparison = c("A:B", "A:C", "A:D", "B:C", "B:D", "C:D"),
#   effect   = c(...), ciLower = c(...), ciUpper = c(...),
#   priLower = c(...), priUpper = c(...)
# )
# bblock <- cnm_bayesian_block(
#   comps,
#   tau = list(mean = ., ciLower = ., ciUpper = .),
#   dic = list(Dbar = ., pD = ., DIC = ., dataPoints = .)
# )
# 
# freq <- cnm_frequentist_block(D, type = "long_binary", sm = "OR")
# write_cnm(build_cnm(freq, bayesian = bblock, title = "Smoking cessation"),
#           "smoking_bayesian.cnm")

## -----------------------------------------------------------------------------
# write_cinema_cnm(D, type = "long_binary", sm = "OR", title = "Smoking (FE/RE)",
#                  file = "smoking_frequentist.cnm")

